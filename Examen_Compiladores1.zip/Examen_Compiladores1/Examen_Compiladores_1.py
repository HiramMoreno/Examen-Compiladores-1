import tkinter as tk
import ply.lex as lex

tokens = [
    'RESERVADO',
    'IDENTIFICADOR',
    'DELIMITADOR',
    'OPERADOR',
    'SIMBOLO',
]

t_RESERVADO = r'(programa|read|printf|int|end)'
t_IDENTIFICADOR = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_DELIMITADOR = r'[(){};]'
t_OPERADOR = r'[=+]'
t_SIMBOLO = r'[.,"]'

t_ignore = ' \t'

lexer = lex.lex()

def analizar(entrada):
    lexer.input(entrada)
    identificadores = []

    while True:
        token = lexer.token()
        if not token:
            break
        if token.type == 'RESERVADO':
            identificadores.append(f"RESERVADO:    {token.value}")
        elif token.type == 'IDENTIFICADOR':
            identificadores.append(f"IDENTIFICADOR:    {token.value}")
        elif token.type == 'DELIMITADOR':
            identificadores.append(f"DELIMITADOR:    {token.value}")
        elif token.type == 'OPERADOR':
            identificadores.append(f"OPERADOR:    {token.value}")
        elif token.type == 'SIMBOLO':
            identificadores.append(f"SIMBOLO:   {token.value}")
        elif token.type != 'NUMERO':
            identificadores.append(f"NO VALIDO:   {token.value}")

    return identificadores

def analizar_codigo():
    codigo = entrada_texto.get("1.0", tk.END)
    lineas = codigo.split("\n")
    identificadores_totales = []

    for i, linea in enumerate(lineas):
        identificadores_linea = analizar(linea)
        for identificador in identificadores_linea:
            identificadores_totales.append((i + 1, identificador))

    resultado_texto.delete("1.0", tk.END)

    for numero_linea, identificador in identificadores_totales:
        resultado_texto.insert(tk.END, f"Línea {numero_linea}\n{identificador}\n")

    numero_reservadas = len([identificador for _, identificador in identificadores_totales if identificador.startswith("RESERVADO")])
    resultado_texto.insert(tk.END, f"\nCadenas Reservadas Detectadas: {numero_reservadas}\n")
    numero_identificadores = len([identificador for _, identificador in identificadores_totales if identificador.startswith("IDENTIFICADOR")])
    resultado_texto.insert(tk.END, f"\nIdentificadores Detectados: {numero_identificadores}\n")
    numero_delimitadores = len([identificador for _, identificador in identificadores_totales if identificador.startswith("DELIMITADOR")])
    resultado_texto.insert(tk.END, f"\nDelimitadores Detectados: {numero_delimitadores}\n")
    numero_operadores = len([identificador for _, identificador in identificadores_totales if identificador.startswith("OPERADOR")])
    resultado_texto.insert(tk.END, f"\nOperadores Detectados: {numero_operadores}\n")
    numero_simbolos = len([identificador for _, identificador in identificadores_totales if identificador.startswith("SIMBOLO")])
    resultado_texto.insert(tk.END, f"\nSimbolos Detectados: {numero_simbolos}\n")





ventana = tk.Tk()
ventana.geometry("900x580")
ventana.title("Analizador Lexico")
ventana.config(bg="#12657f")


entrada_texto = tk.Text(ventana, font=("Arial", 12), bg="white", fg="black", height=10, width=40)
entrada_texto.place(x=60, y=80)
entrada_texto.configure(insertbackground="Black")


resultado_texto = tk.Text(ventana, font=("Arial", 12), bg="white", fg="black", height=25, width=40)
resultado_texto.place(x=450, y=80)


boton_analizar = tk.Button(ventana, text="Analizar", font=("Arial", 12), bg="#121b29", fg="white", command=analizar_codigo)
boton_analizar.place(x=120, y=280)


boton_borrar = tk.Button(ventana, text="Borrar", font=("Arial", 12), bg="#121b29", fg="white", command=lambda: entrada_texto.delete(1.0, tk.END))
boton_borrar.place(x=280, y=280)

ventana.mainloop()
